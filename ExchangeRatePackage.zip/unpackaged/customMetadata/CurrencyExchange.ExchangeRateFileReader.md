<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ExchangeRateFileReader</label>
    <protected>false</protected>
    <values>
        <field>AllOrNone__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>ConversionRate_Index__c</field>
        <value xsi:type="xsd:double">4.0</value>
    </values>
    <values>
        <field>DecimalPlaces__c</field>
        <value xsi:type="xsd:double">2.0</value>
    </values>
    <values>
        <field>IsoCode_Index__c</field>
        <value xsi:type="xsd:double">3.0</value>
    </values>
    <values>
        <field>isActive__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
</CustomMetadata>
